﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Day16SocialLogin.Startup))]
namespace Day16SocialLogin
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
